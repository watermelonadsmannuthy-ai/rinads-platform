Upload rinads_repo.zip to Cursor and run the master prompt. Images included illustrate feature-flag and multi-tenant architecture.
