# RINADS Salon ERP - Cursor starter repo

This is a starter scaffold for RINADS. Cursor will expand this into a full production-ready multi-tenant Salon ERP.
